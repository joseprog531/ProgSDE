module MeuDB {
	requires java.desktop;
	requires java.sql;
}

//Esse comentario é so um teste